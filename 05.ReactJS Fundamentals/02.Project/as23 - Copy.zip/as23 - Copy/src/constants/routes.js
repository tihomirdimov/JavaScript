export const HOME = '/';
export const SIGN_UP = '/signup';
export const SIGN_IN = '/signin';
export const ADMINISTRATION = '/administration';
export const ACCOUNT = '/account';
export const PASSWORD_FORGET = '/forget-password';
export const PLAYERS = '/players';
export const GAMES = '/games';


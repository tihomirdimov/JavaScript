import React, { Component } from 'react';

class GamesList extends Component {
  render() {
    return (
    <div style={{marginTop: '10px' }}>
      <h5>All Games</h5>
    </div>
    );
   }
}

export default GamesList;
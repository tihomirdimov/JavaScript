import React from 'react';

const HomePage = () =>
  <div>
    <h1>Landing Page</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent accumsan sapien eu nisl hendrerit, sit amet dictum nisi pharetra. Aliquam neque ante, vulputate eget nisi nec, dapibus scelerisque ipsum. Donec a mollis turpis, et congue lacus. Suspendisse pellentesque fermentum neque, vitae rhoncus mi sodales tristique. Nulla vitae massa magna. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc in pharetra dolor. Sed at euismod enim, eu pellentesque eros. Sed sollicitudin aliquam volutpat. Nunc sed pulvinar erat, imperdiet hendrerit nibh. Nulla facilisi. Donec convallis dignissim lobortis.
    </p>
    <p>
      Vivamus dignissim elit non aliquam sodales. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc auctor urna orci, ac ornare sapien aliquet eu. Nunc blandit nisl ex, quis ultrices nibh efficitur non. Nulla euismod lorem nulla, et rhoncus arcu euismod quis. Nam porttitor gravida dolor, ut volutpat felis vehicula a. Fusce volutpat quis sapien a sagittis. Aliquam placerat tellus purus, eu varius dui bibendum sed. Integer ligula enim, mattis ut turpis et, mattis venenatis diam. Maecenas molestie et tortor ut volutpat. Vestibulum ultricies orci vitae porta feugiat.
      </p>
    <p>
      Sed luctus molestie risus at sodales. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vivamus elementum condimentum auctor. Donec in lobortis magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed et justo aliquam, sollicitudin elit in, facilisis ligula. Proin interdum cursus metus, a sagittis quam accumsan sit amet. Pellentesque porttitor varius nisi malesuada condimentum.
      </p>
    <p>
      Proin placerat tortor vel enim auctor ornare. Nunc at ipsum quis leo scelerisque scelerisque ac vel arcu. Integer felis urna, bibendum eget sagittis id, dignissim eu odio. Proin suscipit eu magna ut convallis. Nam eget ex in augue viverra cursus id vel nulla. Aenean ex elit, porta eget felis ac, venenatis egestas quam. Etiam id dui sed felis eleifend rhoncus ac id nisl. Duis quam dolor, laoreet vel laoreet id, tempor quis urna.
      </p>
    <p>
      Donec sed dolor nec nulla pulvinar cursus vel vel ipsum. Phasellus tincidunt, dui sit amet vehicula sollicitudin, ligula sem suscipit quam, eu molestie est dui in nisl. Etiam ut facilisis augue. Fusce lorem tellus, finibus at aliquam ut, ornare vitae nisi. Maecenas luctus semper massa, a lobortis purus cursus id. Duis semper laoreet mauris nec porta. Nullam aliquet nulla id mauris congue, nec maximus urna vulputate. Cras hendrerit posuere venenatis. Sed tincidunt justo non blandit efficitur. Donec dictum turpis quis cursus ultricies.
      </p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent accumsan sapien eu nisl hendrerit, sit amet dictum nisi pharetra. Aliquam neque ante, vulputate eget nisi nec, dapibus scelerisque ipsum. Donec a mollis turpis, et congue lacus. Suspendisse pellentesque fermentum neque, vitae rhoncus mi sodales tristique. Nulla vitae massa magna. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc in pharetra dolor. Sed at euismod enim, eu pellentesque eros. Sed sollicitudin aliquam volutpat. Nunc sed pulvinar erat, imperdiet hendrerit nibh. Nulla facilisi. Donec convallis dignissim lobortis.
    </p>
    <p>
      Vivamus dignissim elit non aliquam sodales. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nunc auctor urna orci, ac ornare sapien aliquet eu. Nunc blandit nisl ex, quis ultrices nibh efficitur non. Nulla euismod lorem nulla, et rhoncus arcu euismod quis. Nam porttitor gravida dolor, ut volutpat felis vehicula a. Fusce volutpat quis sapien a sagittis. Aliquam placerat tellus purus, eu varius dui bibendum sed. Integer ligula enim, mattis ut turpis et, mattis venenatis diam. Maecenas molestie et tortor ut volutpat. Vestibulum ultricies orci vitae porta feugiat.
      </p>
    <p>
      Sed luctus molestie risus at sodales. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vivamus elementum condimentum auctor. Donec in lobortis magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed et justo aliquam, sollicitudin elit in, facilisis ligula. Proin interdum cursus metus, a sagittis quam accumsan sit amet. Pellentesque porttitor varius nisi malesuada condimentum.
      </p>
    <p>
      Proin placerat tortor vel enim auctor ornare. Nunc at ipsum quis leo scelerisque scelerisque ac vel arcu. Integer felis urna, bibendum eget sagittis id, dignissim eu odio. Proin suscipit eu magna ut convallis. Nam eget ex in augue viverra cursus id vel nulla. Aenean ex elit, porta eget felis ac, venenatis egestas quam. Etiam id dui sed felis eleifend rhoncus ac id nisl. Duis quam dolor, laoreet vel laoreet id, tempor quis urna.
      </p>
    <p>
      Donec sed dolor nec nulla pulvinar cursus vel vel ipsum. Phasellus tincidunt, dui sit amet vehicula sollicitudin, ligula sem suscipit quam, eu molestie est dui in nisl. Etiam ut facilisis augue. Fusce lorem tellus, finibus at aliquam ut, ornare vitae nisi. Maecenas luctus semper massa, a lobortis purus cursus id. Duis semper laoreet mauris nec porta. Nullam aliquet nulla id mauris congue, nec maximus urna vulputate. Cras hendrerit posuere venenatis. Sed tincidunt justo non blandit efficitur. Donec dictum turpis quis cursus ultricies.
      </p>
  </div>
   
export default HomePage;
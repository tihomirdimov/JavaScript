const Article = require('mongoose').model('Article');


async function getAll() {
    const articles = await Article.find({}).sort({ title: 'descending' });
    return articles;
}

async function create(data) {
    const title = data.title;
    const edits = [{ author: data.author, content: data.content }];
    return await Article.create({
        title,
        edits,
    });
}

async function getById(id) {
    const article = await Article.findById(id);
    const latestContent = article.edits.sort(function (a, b) {
        return b.creationDate - b.creationDate;
    });
    article.latestContent = latestContent[0].content;
    if (!article) {
        throw new Error(`Article not found: ${id}`);
    }
    return article;
}

async function updateArticle(id, content, author) {
    try {
        await Article.update(
            { _id: id },
            { $push: { edits: { 'author': author, 'content': content } }}
        )
    }
    catch (err) {
        console.log(err.message)
        return;
    }
}

module.exports = {
    getAll,
    create,
    getById,
    updateArticle
};